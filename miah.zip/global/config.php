<?php

define("key", "miahpas");
define("cod", "AES-128-ECB");

define("servidor", "localhost");
define("usuario","root");
define("password","");
define("db","miah_pasteleria");
?>